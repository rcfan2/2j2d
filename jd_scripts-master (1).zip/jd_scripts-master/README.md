## 自用，请不要fork!
## 特别说明
- [作者仓库](https://github.com/lxk0301/jd_scripts)
- [作者TG频道](https://t.me/JD_fruit_pet)